﻿using System;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Convertitore
{
    class Program
    {
        static void Main(string[] args)
        {
            // Percorso del file XML va inserito
            string xmlFilePath = "";

            // Carica e pulisci l'XML
            XDocument xmlDoc = XDocument.Load(xmlFilePath);
            // Rimuove i namespace e le dichiarazioni di namespace
            RemoveNamespaces(xmlDoc.Root);
            // Converti XML a JSON e manipola per rimuovere i valori nulli
            string json = JsonConvert.SerializeXNode(xmlDoc, Formatting.Indented);

            var jsonObject = JObject.Parse(json);
            // Rimuove gli attributi di namespace dal JSON
            RemoveNamespaceAttributes(jsonObject);
            // Rimuove i valori nulli
            RemoveNulls(jsonObject);
            // Rimuove l'intestazione XML se presente
            RemoveXmlHeader(jsonObject);
            // Ottieni il percorso della sottocartella JsonToXML
            string jsonToXMLFolderPath = GetJsonToXMLFolderPath();
            // Crea il nome del file JSON con il nome del file XML e data e ora
            string jsonFileName = CreateJsonFileName(xmlFilePath);
            // Salva il JSON risultante nella sottocartella
            Console.WriteLine(jsonObject.ToString(Formatting.Indented));
            SaveJsonToFile(jsonObject, jsonToXMLFolderPath, jsonFileName);
            Console.ReadLine();
        }

        static void RemoveNamespaces(XElement element)
        {
            element.Name = element.Name.LocalName;
            foreach (var attribute in element.Attributes().ToList())
                if (attribute.IsNamespaceDeclaration) attribute.Remove();
            foreach (var child in element.Elements())
                RemoveNamespaces(child);
        }

        static void RemoveNulls(JToken token)
        {
            if (token.Type == JTokenType.Object)
            {
                foreach (var property in token.Children<JProperty>().ToList())
                {
                    if (property.Value.Type == JTokenType.Null)
                        property.Value = string.Empty;
                    else
                        RemoveNulls(property.Value);
                }
            }
            else if (token.Type == JTokenType.Array)
            {
                foreach (var item in token.Children().ToList())
                    RemoveNulls(item);
            }
        }

        static void RemoveNamespaceAttributes(JObject jsonObject)
        {
            foreach (var property in jsonObject.Properties().ToList())
            {
                //per toglire la parte all'interno del nodo padre
                if (property.Name.StartsWith("@xmlns"))
                {
                    property.Remove();
                }
                else if (property.Value.Type == JTokenType.Object)
                {
                    RemoveNamespaceAttributes((JObject)property.Value);
                }
                else if (property.Value.Type == JTokenType.Array)
                {
                    foreach (var item in property.Value.Children<JObject>())
                    {
                        RemoveNamespaceAttributes(item);
                    }
                }
            }
        }

        // Funzione per rimuovere l'intestazione XML dal JSON
        static void RemoveXmlHeader(JObject jsonObject)
        {
            // Rimuove il nodo dell'intestazione XML, se presente
            if (jsonObject.ContainsKey("?xml"))
            {
                jsonObject.Remove("?xml");
            }
        }

        // Funzione per ottenere il percorso della sottocartella JsonToXML
        static string GetJsonToXMLFolderPath()
        {
            // Ottieni il percorso del desktop dell'utente corrente
            string SavePath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            // Percorso della sottocartella JsonToXML
            string jsonToXMLFolderPath = Path.Combine(SavePath, "XMLToJson");
            // Crea la sottocartella se non esiste
            if (!Directory.Exists(jsonToXMLFolderPath))
            {
                Directory.CreateDirectory(jsonToXMLFolderPath);
            }
            return jsonToXMLFolderPath;
        }

        // Funzione per creare il nome del file JSON con il nome del file XML e data e ora
        static string CreateJsonFileName(string xmlFilePath)
        {
            // Ottieni il nome del file senza estensione
            string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(xmlFilePath);
            // Ottieni il timestamp corrente
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
            // Crea il nome del file JSON
            return $"{fileNameWithoutExtension}_{timestamp}.json";
        }

        // Funzione per salvare il JSON nel file
        static void SaveJsonToFile(JObject jsonObject, string folderPath, string fileName)
        {
            // Combina il percorso della sottocartella con il nome del file
            string filePath = Path.Combine(folderPath, fileName);
            // Salva il JSON nel file specificato
            File.WriteAllText(filePath, jsonObject.ToString(Formatting.Indented));
            Console.WriteLine($"File salvato nella sottocartella XMLToJson in Local di AppData come {fileName}");
        }
    }
}
