﻿using System;
using System.IO;
using System.Xml.Linq;
using Newtonsoft.Json;

namespace JsonToXmlConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            //Percorso del file JSON va inserito
            string jsonFilePath = "";

            // Leggi il file JSON, il programma schianta se non si passa nulla
            string jsonContent = File.ReadAllText(jsonFilePath);

            // Converte JSON in XML
            XDocument xmlDoc;
            try
            {
                xmlDoc = JsonConvert.DeserializeXNode(jsonContent);
                if (xmlDoc == null)
                {
                    Console.WriteLine("La conversione del JSON in XML è fallita.");
                    return; // Esci se la conversione fallisce
                }
            }
            catch (JsonException ex)
            {
                Console.WriteLine($"Errore nella conversione del JSON in XML: {ex.Message}");
                return; // Esci se c'è un errore nella conversione
            }

            // Rimuovi l'intestazione XML se presente
            RemoveXmlHeader(xmlDoc);

            // Funzione ricorsiva per rimuovere i prefissi
            void RemovePrefixes(XElement element)
            {
                element.Name = element.Name.LocalName;
                foreach (var attribute in element.Attributes())
                    element.SetAttributeValue(attribute.Name.LocalName, attribute.Value);
                foreach (var child in element.Elements())
                    RemovePrefixes(child);
            }

            RemovePrefixes(xmlDoc.Root);

            // Stampa il documento XML a console
            Console.WriteLine(xmlDoc.ToString(SaveOptions.None));

            // Salva il documento XML nella sottocartella JsonToXML
            SaveXmlToJsonToXMLFolder(xmlDoc, jsonFilePath);
            Console.ReadLine();
        }

        // Funzione per rimuovere l'intestazione XML se è presente come dichiarazione
        static void RemoveXmlHeader(XDocument xmlDoc)
        {
            // Rimuovi l'intestazione XML se presente
            if (xmlDoc.Declaration != null)
            {
                xmlDoc.Declaration = null;

            }
        }

        // Funzione per ottenere il nome del file senza estensione
        static string GetFileNameWithoutExtension(string filePath)
        {
            return Path.GetFileNameWithoutExtension(filePath);
        }

        // Funzione per ottenere il percorso della sottocartella JsonToXML
        static string GetJsonToXMLFolderPath()
        {
            // Ottieni il percorso della cartella dell'applicazione
            string appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            // Percorso della sottocartella JsonToXML
            string jsonToXMLFolderPath = Path.Combine(appDataPath, "JsonToXML");
            // Crea la sottocartella se non esiste
            if (!Directory.Exists(jsonToXMLFolderPath))
            {
                Directory.CreateDirectory(jsonToXMLFolderPath);
            }
            return jsonToXMLFolderPath;
        }

        // Funzione per salvare l'XML nella sottocartella JsonToXML con data e ora nel nome
        static void SaveXmlToJsonToXMLFolder(XDocument xmlDoc, string jsonFilePath)
        {
            // Ottieni il nome del file senza estensione
            string fileNameWithoutExtension = GetFileNameWithoutExtension(jsonFilePath);

            // Aggiungi la data e l'ora al nome del file
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd_HH-mm-ss");
            string xmlFileName = $"{fileNameWithoutExtension}_{timestamp}.xml";

            // Ottieni il percorso della sottocartella JsonToXML
            string jsonToXMLFolderPath = GetJsonToXMLFolderPath();
            // Combina il percorso della sottocartella con il nome del file
            string filePath = Path.Combine(jsonToXMLFolderPath, xmlFileName);

            // Converti il documento XML in una stringa senza intestazione
            string xmlString = xmlDoc.ToString(SaveOptions.None);

            // Rimuovi l'intestazione XML se è presente nella stringa
            xmlString = RemoveXmlHeaderFromString(xmlString);

            // Salva la stringa XML nel file specificato
            File.WriteAllText(filePath, xmlString);
            Console.WriteLine($"File salvato nella sottocartella JsonToXML in Local in AppData come {xmlFileName}");
        }

        // Funzione per rimuovere l'intestazione XML da una stringa XML
        static string RemoveXmlHeaderFromString(string xmlString)
        {
            //Per l'intestazione xml
            string headerPattern = @"^<\?xml[^?>]*\?>\s*";
            return System.Text.RegularExpressions.Regex.Replace(xmlString, headerPattern, string.Empty);
        }
    }
}
